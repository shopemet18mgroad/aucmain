<?php 
	include('./header.php');
?>
    <!---  body  design  -->
    
  
	<div class="content w-100">
	<div class="middleboxtnc w-75">
	<div class="table-container w-100">
	<h4 align="center">Sellers Registration Form</h4>
	<h6>(All field's marked with * are mandatory)</h6>
     
  <table class="table table-bordered table-sm">
   
    <tbody>
      <tr>
        <td class="font"><b>Company*</b></td>
        <td><input class="form-input-syle w-75" type="text" id="fname" name="fname" size="50"></td>       
      </tr>
      <tr>
        <td class="font"><b>Type of seller*</b></td>
        <td><input class="form-input-syle w-75" type="text" id="seller" name="seller" size="50"></td>
      </tr>
      <tr>
        <td class="font"><b>Street*</b></td>
        <td><input class="form-input-syle w-75" type="text" id="street" name="street" size="50"></td>       
      </tr>
	   <tr>
        <td class="font"><b>City*</b></td>
        <td><input class="form-input-syle w-75" type="text" id="city" name="city" size="50"></td>      
      </tr>
	  <tr>
        <td class="font"><b>Pin*</b></td>
        <td><input class="form-input-syle w-75" type="text" id="pin" name="pin" size="50"></td>      
      </tr>
	  <tr>
        <td class="font"><b>State/Union Ter.*:</b></td>
        <td><select class="form-input-syle w-75" id="state" name="state" >
			<option value="one" selected>-----------category1--------</option>
			<option value="two">category2</option>
			<option value="three" >category3</option>
			<option value="four">category4</option>
			</select></td>      
      </tr>	
	  <tr>
        <td class="font"><b>Country *:</b></td>
        <td><input class="form-input-syle w-75" type="text" id="country" name="country" size="50"></td>       
      </tr>
      <tr>
        <td class="font"><b>Location *:</b></td>
        <td><input class="form-input-syle w-75" type="text" id="location" name="location" size="50"></td>
      </tr>
      <tr>
        <td class="font"><b>Email*</b></td>
        <td><input class="form-input-syle w-75" type="text" id="email" name="email" size="50"></td>       
      </tr>
	   <tr>
        <td class="font"><b>Phone*</b></td>
        <td><input class="form-input-syle w-75" type="text" id="phone" name="phone" size="50"></td>      
      </tr>
	  <tr>
        <td class="font"><b>Fax*</b></td>
        <td><input class="form-input-syle w-75" type="text" id="fax" name="fax" size="50"></td>      
      </tr>
	   </tbody>
	   </table>
		
    
		<div class="text-center" style="position:relative;">
	
		<a href="agreementforseller.php"><button type="button" class="btn btn-primary">Agree</button></a>
	
		
	    <a href="index.php"><button type="button" class="btn btn-primary">Disagree</button></a>
		
		</div>


</div>
</div>
	
	 <!---  body  design  -->

        <!---  footer  -->

    <?php 
	include('./footer.php');
?>