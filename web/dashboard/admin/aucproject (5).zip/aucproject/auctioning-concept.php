<?php 
	include('./header.php');
?>
		<div class="container">
		  <div class="row">
			<div class="col-md-12">
			 <div class="aboutus-section">
        <div class="container">
			  <div class="row">
				<div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="aboutus">
                        <h2 class="aboutus-title">OUR AUCTIONING CONCEPTS</h2>
                        <p class="aboutus-text"><span class="textsize">FORWARD BIDDING:</span></p>
<p class="aboutus-text">In forward auctions, bidders who offer the highest bid win the thing. The merchant will set up the things accessible to purchase and bidders will start the bid for these, therefore driving the cost up. Dealers may settle a hold value with the goal that deals don't fall beneath this. These sorts of online auctions are notable for bidding and purchasing collectibles additionally may offer business to business.
</br></br>
Auction sites have their own guidelines, for example, whether merchants require a specific business accreditation to partake and whether to set an enrollment expense before utilize. Another thought will be the way installment is made; either between the gatherings included or through the site itself. Merchant profiles are built up and remunerated by the more they offer and the more dependable they substantiate themselves as far as conveyance and quality.</p>

<p class="aboutus-text"><span class="textsize">REVERSE BIDDING:</span></p>
<p class="aboutus-text">In this sort of auction, bidders who offer the least bid wins the thing (the "thing" in Reverse auction is normally an agreement for business). The occasion itself will keep going for a matter of only a couple of hours. Reverse auctions are essential for supply chains (especially electronic) and are seen as a cash sparing activity. These switch sales are turning into an undeniably prominent approach to work together through the web.</p>
                    </div>
                </div>
			  </div>
            
        </div>
    </div>
			   
			</div>
			
			
		  </div>
		</div>
		
		<?php 
	include('./footer.php');
?>