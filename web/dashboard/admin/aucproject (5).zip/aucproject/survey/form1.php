
   <?php include "header.php";?>
		
		<div class="container dealsbox">
			 <div class="row">
				<div class="col-md-12">
						<div class="deals-header">
							<h4><i class="icon-dashboard"></i><i class="fa fa-tachometer" aria-hidden="true"></i>&nbsp; Dashboard</h4>
						</div>
				</div>
			 </div>	
			 <div class="row">
				
				<div class="col-md-12">
					<div class="deals-tab-table">
							<ul class="nav nav-tabs border-0" id="myTab" role="tablist">
							
								<li class="nav-item">
									<a class="nav-link active border border-primary border-bottom-0" id="hvd-tab" data-toggle="tab" href="#hvd" role="tab" aria-controls="hvd" aria-selected="true"><b>Form1</b></a>
								</li>
								
								
							</ul>

							<div class="tab-content w-100">
								<div class="tab-pane h-100 p-3 fade show active border border-primary" id="hvd" role="tabpanel" aria-labelledby="hvd-tab">
									<div class="table-holder"> 
										<div class="tab-content">
											<table class="table table-bordered table-sm text-center">
												<thead class="thead-auc">
												
												
												</thead>
												<tbody>
									
												<tr><td colspan="10" style="background-color:#b2bdc3;"><strong>E-Auctions/Bidder Survey Form</strong></td></tr>
												
												<tr class="cinpt w-100">
												<td colspan="10">
												<div class="cinpt">
												<p><strong>Namaste,</strong></p>
											
												<p>I am <input class="inpt" type="text" id="name" name="name" size="10"> from <a href="“www.aucjunction.com”">www.aucjunction.com</a>, we are coming up with a new E- auction website to dispose
												of Industrial Scrap/waste<br>(Bi-Product), through which you can get more bidders from Pan India.</p>
												<p><small>So in this regard can you please spare few minutes of your’s valuable time 3-5mins to understand and cater to your needs in a better way.</small></p>
												<p><b>Note:</b> All the information provided by you will be used only for office purposes R&D, We assure you
												confidentially at all levels, and<br> will never be shared outside Shopemet Networks Pvt Ltd.</p>
												</div>
												</td>
												</tr>
												
												<tr class="cinpt w-100">
												<td colspan="10">
												<div class="cinpt">
												<p>Name of the Company/Firm: 
												<input class="inpt w-100" type="text" id="company" name="company" size="80"></p>
												<p>Corporate Office Address:
													<input class="inpt w-100" type="text" id="address" name="address" size="83"></p>
												<p>Website/Telephone/Mobile/Email ID:
													<input class="inpt w-100" type="text" id="contact" name="contact" size="75"></p>
												<p>Contact person’s Name/Designation/Number/Email:
													<input class="inpt w-100" type="text" id="contactp" name="contactp" size="62"></p>
													</div>
												</td></tr>
												
												
												<tr class="cinpt  w-100">
												
												<td>
												<div class="cinpt">
												<p><b>Current Status:</b><br></p>
												<div class="form-check form-check-inline ">
                                                <input type="checkbox" class="form-check-input" id="proprietor">
                                                <label class="form-check-label" for="proprietor">Proprietorship</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="partnership">
                                                <label class="form-check-label" for="partnership">Partnership</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="corporation">
                                                <label class="form-check-label" for="corporation">Corporation</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="pvt.ltd">
                                                <label class="form-check-label" for="pvt.ltd">Pvt.Ltd</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="publicsector">
                                                <label class="form-check-label" for="publicsector">Public sector</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="smallbusi">
                                                <label class="form-check-label" for="smallbusi">Small business</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="limited">
                                                <label class="form-check-label" for="limited">Limited</label>
												</div>
												</div>
												
												
												</td></tr>
												
												<tr class="cinpt  w-100">
												
												<td>
												<div class="cinpt">
												<p><b>Type of Business:</b><br></p>
												<div class="form-check form-check-inline ">
                                                <input type="checkbox" class="form-check-input" id="manuf">
                                                <label class="form-check-label" for="manuf">Manufacture</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="distributer">
                                                <label class="form-check-label" for="distributer">Distributer</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="trader">
                                                <label class="form-check-label" for="trader">Trader</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="importer">
                                                <label class="form-check-label" for="importer">Importer</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="secondmenuf">
                                                <label class="form-check-label" for="secondmenuf">Secondary Manufacturer</label>
												</div>
												</div>
												
												
												</td></tr>
												
												<tr class="cinpt  w-100">
												
												<td>
												<div class="cinpt">
												<p>Is your company PCB certified,
												<input class="inpt" type="text" id="pcbcertified" name="pcbcertified" size="10">
												do you participate in online auctions
												<input class="inpt" type="text" id="onlinauction" name="onlinauction" size="10">
												, is it in
												Tons, KGs, Lots,<br>Quantity/numbers, Meters or depends on the product which is been disposed?
												<input class="inpt w-100" type="text" id="weight" name="weight" size="40">
												<input class="inpt w-100" type="text" id="weight" name="weight" size="100">
												</p>
												</div>
												</td>
												</tr>
												
												
												
												
												<tr class="cinpt  w-100">
												
												<td>
												<div class="cinpt">
												<p>If you were to participate in an online auction what are the products would you likely to bid(Sell or Buy)
												on?</p>
												<div class="form-check form-check-inline ">
                                                <input type="checkbox" class="form-check-input" id="electronicproduct">
                                                <label class="form-check-label" for="electronicproduct">Electronics Products(eg.E-Waste)</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="metal">
                                                <label class="form-check-label" for="metal">Metals(e.g Iron/Steel)</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="plastic">
                                                <label class="form-check-label" for="plastic">Plastic</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="wood">
                                                <label class="form-check-label" for="wood">Wood</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="hazinduswaste">
                                                <label class="form-check-label" for="hazinduswaste">Hazardous Industrial waste(PCB certification)</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="nonhazinduswaste">
                                                <label class="form-check-label" for="nonhazinduswaste">Non-Hazardous</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="miscelleneous">
                                                <label class="form-check-label" for="miscelleneous">Miscelleneous</label>
												</div>
												<p>others please specify:
												<input class="inpt w-100" type="text" id="otherspec" name="otherspec" size="80"></p>
												
											</div>
												
												
												</td></tr>
												<tr class="cinpt  w-100">
												
												<td>
											<div class="cinpt">
												<p>When was the last time you participated in Auctions to Sell or Buy be it any category product? How many
												auctions in a year?<input class="inpt w-100" type="text" id="fname" name="fname" size="80"><br></p>

												<div class="form-check form-check-inline ">
                                                <input type="checkbox" class="form-check-input" id="lastweek">
                                                <label class="form-check-label" for="lastweek">In the last one week</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="lastm">
                                                <label class="form-check-label" for="lastm"">In the last one month</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="lastthreem"">
                                                <label class="form-check-label" for="lastthreem">In the last three months</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="lastsixm">
                                                <label class="form-check-label" for="lastsixm">In the last six months</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="last12m">
                                                <label class="form-check-label" for="last12m">In the last 12 months</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="morethan12mago">
                                                <label class="form-check-label" for="morethan12mago">More than 12 months ago</label>
												</div>
												</div>
												
												
												</td></tr>
												<tr class="cinpt  w-100">
												
												<td>
												<div class="cinpt">
												<p>What is the approximate quantity of Industrial scrap(Bi-Product) waste generated
												by your firm in a year?
												
												<input class="inpt w-100" type="text" id="quantitiy" name="quantitiy" size="70"></p>
												<p>Material category value of “ Lot” each time when you Dispose/Auction:
												<input class="inpt w-100" type="text" id="value" name="value" size="70"></p>
												</div>
												</td>
												</tr>
												
												<tr class="cinpt  w-100">
												
												<td>
												<div class="cinpt">
												<p>Bidding locations you can participate, only Bangalore, with in Karnataka, only in South states
												or Pan India.
												<input class="inpt w-100" type="text" id="location" name="location" size="80"></p>
												</div>
												</td></tr>
												
												<tr class="cinpt  w-100">
												
												<td>
												<div class="cinpt">
												<p>What all Auction websites you have visited/parcipated for bidding in the recent past years?
												<input class="inpt w-100" type="text" id="visited" name="visited" size="80"></p>
												</div>
												</td>
												</tr>
												
												<tr class="cinpt  w-100">
												
												<td>
												<div class="cinpt">
												<p>When you are buying or selling through the auction websites who influenced are you with following ?<br></p>
												
												<div class="form-check form-check-inline ">
                                                <input type="checkbox" class="form-check-input" id="description">
                                                <label class="form-check-label" for="description">Description</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="extremelyinfluenced">
                                                <label class="form-check-label" for="extremelyinfluenced">Extremely influenced</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="somewhatinfluenced">
                                                <label class="form-check-label" for="somewhatinfluenced">Somewhat influenced</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="veryinfluenced">
                                                <label class="form-check-label" for="veryinfluenced">Very influenced</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="feedback">
                                                <label class="form-check-label" for="feedback">Feedback</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="cseller">
                                                <label class="form-check-label" for="cseller">Company/Shop Seller</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="price">
                                                <label class="form-check-label" for="price">Price</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="itemlocation">
                                                <label class="form-check-label" for="itemlocation">Location of item</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="cseller">
                                                <label class="form-check-label" for="cseller">Company/Shop Seller</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="notsoinfluenced">
                                                <label class="form-check-label" for="notsoinfluenced">Not so influenced</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="notatallinfluenced">
                                                <label class="form-check-label" for="notatallinfluenced">Not at all influenced</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="picture">
                                                <label class="form-check-label" for="picture">Picture</label>
												</div>
												
												</div>
												
												</td></tr>
												
												<tr class="cinpt  w-100">
												
												<td>
												<div class="cinpt">
												<p>Are you primary user decision maker in your Company/Firm regarding disposal of above mentiioned
												Product category:<br></p>
												
												Yes <div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="yes">
                                                <label class="form-check-label" for="yes"></label>
											   </div>
												No <div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="no">
                                                <label class="form-check-label" for="no"></label>
												</div>
												
												If No please specify the contact person:
												<input class="inpt w-100" type="text" id="contactp" name="contactp" size="50">
												</div>
												</td></tr>
												 
												<tr class="cinpt  w-100">
												
												<td>
												<div class="cinpt">
												<p>Finally thanking you for your valuable feedback, Please free to share any suggestions, to improve our
												services pertaining to<br> disposals of Industrial waste(Bi-Products) through our website
												<a href="www.aucjunction.com"><u>www.aucjunction.com</u></a>?<br>
												<input class="inpt w-100" type="text" id="feedback" name="feedback" size="90"></p>
												</div>
												
												</td>
												</tr>
												
												<tr class="cinpt  w-100">
												<td colspan="10">
												<div class="cinpt">
												<p>We are going to launch <a href="www.aucjunction.com ">www.aucjunction.com </a>as you can get competitors and target all bidders across
												India, were in you can get the<br> best price each time you bid, very soon my Manager will get in touch with
												you, once again thank you so much for your time.</p>
												</div>
												</td>
												</tr>
												
												</tbody>
												</table>
											<a href="#"><button type="button" class="btn btn-primary">Submit</button></a>

								
							</div>
						</div>
				</div>
			</div>	
		</div>
		</div>
		</div>
		</div>
		
		<?php
		include "footer.php";
		
		?>
		
		
		


