<?php 
	include('./a-header.php');
	include('./a-menubar.php');
?>
	
				<div class="col-md-9">
					<div class="deals-tab-table">
							<ul class="nav nav-tabs border-0" id="myTab" role="tablist">
							
								<li class="nav-item">
									<a class="nav-link active border border-primary border-bottom-0" id="hvd-tab" data-toggle="tab" href="#hvd" role="tab" aria-controls="hvd" aria-selected="true"><b>Best Sellers</b></a>
								</li>
								
							</ul>

							<div class="tab-content w-100">
								<div class="tab-pane h-100 p-3 active border border-primary" id="hvd" role="tabpanel" aria-labelledby="hvd-tab">
										<div class="table-holder">
										
										
													
													
								
											<table class="table table-bordered table-striped table-sm mt-2">									
											
												<thead class="thead-auc">
												
													<tr>
														<th width="10%">Company Name</th>
														<th width="10%">Location</th>
														<th width="10%">Lot No.</th>
														<th width="10%">Lot Name</th>
														<th width="10%">Quantity</th>
														<th width="10%">Purity</th>
														<th width="10%">Final Bid price</th>
														<th width="10%">Discription</th>
														<th width="10%">Date/Time</th>
														<th width="10%">Amount</th>
														
														
														
													</tr>
												</thead>
												<tbody>
													<tr>
														
														<td>XYZ Company</td>
														<td>XYZ Location</td>
														<td>1</td>
														<td>IRON</td>
														<td>100</td>
														<td>80%</td>
														<td>1,00,000</td>
														<td>Type: Pipes, Sheets, Rods, Blocks & Etc
                                                         </td>
														<td>28-07-2020 at 9:00am</td>
														<td>5,00,000</td>
														
														
														</tr>
														<tr>
														
														<td>XYZ Company</td>
														<td>XYZ Location</td>
														<td>1</td>
														<td>IRON</td>
														<td>100</td>
														<td>80%</td>
														<td>1,00,000</td>
														<td>Type: Pipes, Sheets, Rods, Blocks & Etc
                                                         </td>
														<td>28-07-2020 at 9:00am</td>
														<td>5,00,000</td>
														
														
														</tr>
														<tr>
														
														<td>XYZ Company</td>
														<td>XYZ Location</td>
														<td>1</td>
														<td>IRON</td>
														<td>100</td>
														<td>80%</td>
														<td>1,00,000</td>
														<td>Type: Pipes, Sheets, Rods, Blocks & Etc
                                                         </td>
														<td>28-07-2020 at 9:00am</td>
														<td>5,00,000</td>
														
														
														</tr>
													
													
													
													
													
												</tbody>
											</table>

		  <a href="#"><button type="button" class="btn btn-primary">Download</button></a>
		
	       <a href='#'><button type="button" class="btn btn-primary">Share</button></a>
		
											
											
											
										</div>    		
								</div>
								
							</div>
							
							<nav aria-label="Page navigation example">
									<ul class="pagination justify-content-center pagination-sm">
										<li class="page-item disabled">
										<a class="page-link" href="#" tabindex="-1"><<</a>
										</li>
										<li class="page-item"><a class="page-link" href="#">1</a></li>
										<li class="page-item"><a class="page-link" href="#">2</a></li>
										<li class="page-item"><a class="page-link" href="#">3</a></li>
										<li class="page-item">
										<a class="page-link" href="#">>></a>
										</li>
									</ul>
							</nav>	
						</div>
				</div>
			</div>	
		</div>
<?php 
	include('./a-footer.php');
	?>
