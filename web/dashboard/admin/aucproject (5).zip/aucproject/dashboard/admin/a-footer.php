<section id="footer">
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-1">
					<ul class="list-unstyled list-inline social text-center">
						<li class="list-inline-item"><a href=""><i class="fa fa-facebook"></i></a></li>
						<li class="list-inline-item"><a href=""><i class="fa fa-twitter"></i></a></li>
						<li class="list-inline-item"><a href=""><i class="fa fa-instagram"></i></a></li>
						<li class="list-inline-item"><a href=""><i class="fa fa-google-plus"></i></a></li>
						<li class="list-inline-item"><a href="" target="_blank"><i class="fa fa-envelope"></i></a></li>
					</ul>
				</div>
				<hr>
			</div>	
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 mt-1 mt-sm-1 text-center text-white">
					<p>Shopemet Networks Private Limited CIN NO :- 2097898098089</p>
					<p class="h6">Aucjunction © All right Reversed.</p>
				</div>
				<hr>
			</div>	
		</div>
	</section>
		
		
		

	
  <!-- Bootstrap core JavaScript-->	
  <script src="../../js/jquery-3.2.2.js"></script>
  <script src="../../js/popper.min.js"></script>
  <script src="../../js/bootstrap.bundle.min.js"></script>
  <script src="../../js/jquery.autoscroll.js" type="text/javascript" charset="utf-8"></script>
  <!-- Core plugin JavaScript-->

</body>

</html>
