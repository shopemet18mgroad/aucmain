<div class="list-group">
						<span href="#" class="list-group-item active"><i class="fa fa-bars"></i>&nbsp;
							Menu Bar
						</span>
						<a href="a-editseller.php" class="list-group-item">	
							<i class="fa fa-user"></i> Seller Registration
						</a>
						<a href="a-editbuyer.php" class="list-group-item">
							<i class="fa fa-user"></i> Buyer Registration 
						</a>
						<a href="a-startauction.php" class="list-group-item">
							<i class="fa fa-folder-open-o"></i> Start Auction
						</a>
						<a href="a-auction.php" class="list-group-item">
							<i class="fa fa-gavel"></i> Auction  
						</a>
						
						<a href="a-emd.php" class="list-group-item">
							<i class="fa fa-money"></i> EMD
						</a>
						<a href="a-report.php" class="list-group-item">
							<i class="fa fa-file"></i> Report
						</a>
						<a href="a-performance.php" class="list-group-item">
							<i class="fa fa-bar-chart"></i> Performance
						</a>
					</div>
					</div>