<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="title" content=">Aucjunction | Junction For Every auction">
  <meta name="description" content="Junction For Every Auction">
  <meta name="keyword" content="Auction, metal scrapes, Ferrous, Non Ferrous and Minor Metals">
  <meta name="author" content="">
  <title>Aucjunction | Junction For Every auction</title>
  <!-- Custom fonts for this template-->
  <link href="../../css/bootstrap.min.css" rel="stylesheet" type="text/css">
  <link href="../../css/dashboard-style.css" rel="stylesheet" type="text/css">
  <!-- Custom styles for this template-->
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" >
</head>
	<body class="">
	<div class="container-fluid top-header">
		<div class="row">
				<div class="col-md-12 contact-header">
					<div class="social-dash pull-right">
						<ul>
							<li><a href=""><i class="fa fa-home" aria-hidden="true"></i>&nbsp Home</a></li>
							<li><a href=""><i class="fa fa-arrow-left" aria-hidden="true"></i>&nbsp Back</a></li>
							<li><i class="fa fa-calendar" aria-hidden="true"></i>&nbsp 22-AUGUST-2020</li>
						</ul>
					</div>		
				</div>
						
		</div>	
	</div>
		
		 <div class="container">
			<div class="d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-3 bg-white border-bottom shadow-sm">
				<h5 class="my-0 mr-md-auto font-weight-normal"><a href="" title="Aucjunction Logo">
					<img class="img-fluid" alt="Aucjunction"  src="../../images/aucjunction.jpg">
					</a></h5>
				<nav class="my-2 my-md-0 mr-md-3 text-dark">
				<i class="fa fa-user-circle fa-2x" aria-hidden="true"></i> Hi, Nishanth S
				</nav>
				<a class="btn btn-outline-primary" href="#"><i class="fa fa-sign-out" aria-hidden="true"></i>&nbsp;Sign Out</a>
			</div>
	     </div>