<div class="list-group">
						<span href="#" class="list-group-item active"><i class="fa fa-bars"></i>&nbsp;
							Menu Bar
						</span>
						<a href="buyer.php" class="list-group-item">
							<i class="fa fa-user"></i> Update Profile
						</a>
						<a href="liveauction.php" class="list-group-item">
							<i class="fa fa-gavel"></i> Forthcoming Auctions 
						</a>
						
						<a href="detailedauc.php" class="list-group-item">
							<i class="fa fa-folder-open-o"></i>  View Bidding Details
						</a>
						<a href="manualbid.php" class="list-group-item">
							<i class="fa fa-bar-chart-o"></i>  Bidding  
						</a>

						<a href="occupied.php" class="list-group-item">
							<i class="fa fa-file"></i> History
						</a>
						<a href="emd.php" class="list-group-item">
							<i class="fa fa-money"></i> My List
						</a>
					</div>        
				</div>