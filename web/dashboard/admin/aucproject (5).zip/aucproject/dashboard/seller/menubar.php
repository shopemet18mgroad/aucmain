
					<div class="list-group">
						<span href="#" class="list-group-item active"><i class="fa fa-bars"></i>&nbsp;
							Menu Bar
						</span>
						<a href="update.php" class="list-group-item">
							<i class="fa fa-user"></i> Update Profile 
						</a>
						<a href="startauctionlink.php" class="list-group-item">
							<i class="fa fa-hand-o-up"></i> Start Auction
						</a>
						<a href="soldproducts.php" class="list-group-item">
							<i class="fa fa-thumbs-o-up"></i> Auction Approvals
						</a>
						<a href="auctiondetail.php" class="list-group-item">
							<i class="fa fa-gavel"></i> View Auctions Detailed
						</a>
						<a href="Biddingdata.php" class="list-group-item">
							<i class="fa fa-bar-chart-o"></i> Bidding Data Details
						</a>
						<a href="reportesold.php" class="list-group-item">
							<i class="fa fa-file"></i> History
						</a>
					</div>        
				</div>
				