<div class="row">
				<div class="col-md-3">
					 <div class="mini-submenu">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</div>
					<div class="list-group">
						<span href="#" class="list-group-item active"><i class="fa fa-bars"></i>&nbsp;
							Menu Bar
						</span>
						<a href="update.html" class="list-group-item">
							<i class="fa fa-user"></i> Update Profile 
						</a>
						<a href="startauctionlink.html" class="list-group-item">
							<i class="fa fa-hand-o-up"></i> Start Auction
						</a>
						<a href="soldproducts.html" class="list-group-item">
							<i class="fa fa-thumbs-o-up"></i> Auction Approvals
						</a>
						<a href="auctiondetail.html" class="list-group-item">
							<i class="fa fa-gavel"></i> View Auctions Detailed
						</a>
						<a href="Biddingdata.html" class="list-group-item">
							<i class="fa fa-bar-chart-o"></i> Bidding Data Details
						</a>
						<a href="reportesold.html" class="list-group-item">
							<i class="fa fa-file"></i> History
						</a>
					</div>        
				</div>
				</div>