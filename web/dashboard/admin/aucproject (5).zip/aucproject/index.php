<?php 
	include('./header.php');
?>
		<div class="container">
		  <div class="row">
			<div class="col-md-3">
			    <div class="newsbox-containertray">
						<div class="newsbox-header">
							<h4>Latest News</h4>
						</div>
						<div class="newsbox">
							<ul class="data-list" data-autoscroll>
								<li><i class="fa fa-hand-o-right" aria-hidden="true"></i>Breaking News 1</li>
								<li><i class="fa fa-hand-o-right" aria-hidden="true"></i> Breaking News 2</li>
								<li><i class="fa fa-hand-o-right" aria-hidden="true"></i> Breaking News 3</li>
								<li><i class="fa fa-hand-o-right" aria-hidden="true"></i> Breaking News 4</li>
								<li><i class="fa fa-hand-o-right" aria-hidden="true"></i> Breaking News 5</li>
								<li><i class="fa fa-hand-o-right" aria-hidden="true"></i> Breaking News 6</li>
								<li><i class="fa fa-hand-o-right" aria-hidden="true"></i> Breaking News 7</li>
								<li><i class="fa fa-hand-o-right" aria-hidden="true"></i> Breaking News 8</li>
								<li><i class="fa fa-hand-o-right" aria-hidden="true"></i> Breaking News 9</li>
								<li><i class="fa fa-hand-o-right" aria-hidden="true"></i> Breaking News 10</li>
								<li><i class="fa fa-hand-o-right" aria-hidden="true"></i> Breaking News 11</li>
								<li><i class="fa fa-hand-o-right" aria-hidden="true"></i> Breaking News 12</li>
								<li><i class="fa fa-hand-o-right" aria-hidden="true"></i> Breaking News 13</li>
								<li><i class="fa fa-hand-o-right" aria-hidden="true"></i> Breaking News 14</li>
							</ul>
						</div>
					</div>
			</div>
			<div class="col-md-9">
					<div class="auclist-containertray">
							<div class="auclisting-header">
							<h4>Oncoming Events</h4>
							</div>
							<div class="tab-holder w-100">
							<ul class="nav nav-tabs border-0" id="myTab" role="tablist">
							
								<li class="nav-item">
									<a class="nav-link active border border-primary border-bottom-0" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Today's Auctions</a>
								</li>
								<li class="nav-item">
									<a class="nav-link border border-primary border-bottom-0" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Upcoming Auctions</a>
								</li>
								<li class="nav-item">
									<a class="nav-link border border-primary border-bottom-0" id="all-tab" data-toggle="tab" href="#all" role="tab" aria-controls="all" aria-selected="true">ALL</a>
								</li>
							</ul>

							<div class="tab-content w-100">
								<div class="tab-pane h-100 p-3 active border border-primary" id="home" role="tabpanel" aria-labelledby="home-tab">
										<div class="table-holder"> 
											<table class="table table-bordered">
												<thead class="thead-auc">
													<tr>
														<th width="30%">Date & Time</th>
														<th width="35%">Company Name</th>
														<th width="35%">Description </th>
														
													</tr>
												</thead>
												<tbody>
													<tr>
													
														<td>10/08/2020 11:00 AM To 12:00 PM</td>
														<td>Aucjunction555CA - Maharashtra</td>
														<td>Miscellaneous Electrical, HVAC, Plumbing, Tool & Tackles Items, Batteries, etc. available at Noida</td>
														
													</tr>
													<tr>
													
														<td>10/08/2020 11:00 AM To 12:00 PM</td>
														<td>Aucjunction555CA - Maharashtra</td>
														<td>Miscellaneous Electrical, HVAC, Plumbing, Tool & Tackles Items, Batteries, etc. available at Noida</td>
														
													</tr>
													<tr>
														
														<td>10/08/2020 11:00 AM To 12:00 PM</td>
														<td>Aucjunction555CA - Maharashtra</td>
														<td>Miscellaneous Electrical, HVAC, Plumbing, Tool & Tackles Items, Batteries, etc. available at Noida</td>
														
													</tr>  
													<tr>
													<td>10/08/2020 11:00 AM To 12:00 PM</td>
														<td>Aucjunction555CA - Maharashtra</td>
														<td>Miscellaneous Electrical, HVAC, Plumbing, Tool & Tackles Items, Batteries, etc. available at Noida</td>
														
													</tr>  													
												</tbody>
											</table>
										</div>    		
								</div>
								<div class="tab-pane h-100 p-3 border border-primary" id="profile" role="tabpanel" aria-labelledby="profile-tab">Upcoming Events 2</div>
								<div class="tab-pane h-100 p-3 border border-primary" id="messages" role="tabpanel" aria-labelledby="messages-tab">Upcoming Events 3</div>
								<div class="tab-pane h-100 p-3 border border-primary" id="settings" role="tabpanel" aria-labelledby="settings-tab">Upcoming Events 4</div>
								<div class="tab-pane h-100 p-3 border border-primary" id="all" role="tabpanel" aria-labelledby="all-tab">ALL</div>
							</div>

						</div>
					</div>
					
			</div>
			
		  </div>
		</div>
		<div class="container dealsbox">
			 <div class="row">
				<div class="col-md-12">
						<div class="deals-header">
							<h4>Deals of The Day</h4>
						</div>
				</div>
				<div class="col-md-12">
						<div class="deals-tab-table">
							<ul class="nav nav-tabs border-0" id="myTab" role="tablist">
							
								<li class="nav-item">
									<a class="nav-link active border border-primary border-bottom-0" id="hvd-tab" data-toggle="tab" href="#hvd" role="tab" aria-controls="hvd" aria-selected="true">High Value Deals</a>
								</li>
								<li class="nav-item">
									<a class="nav-link border border-primary border-bottom-0" id="deals-tab" data-toggle="tab" href="#deals" role="tab" aria-controls="profile" aria-selected="false">Deals of The Day</a>
								</li>
							</ul>

							<div class="tab-content w-100">
								<div class="tab-pane h-100 p-3 active border border-primary" id="hvd" role="tabpanel" aria-labelledby="hvd-tab">
										<div class="table-holder"> 
											<table class="table table-bordered">
												<thead class="thead-auc">
													<tr>
														<th width="20%">Company Name</th>
														<th width="60%">Description</th>
														<th width="20%">Download Details </th>
														
													</tr>
												</thead>
												<tbody>
													<tr>
														
														<td>JCB India Ltd. (Ballabgarh, Jaipur & Pune)</td>
														<td>JCB India Ltd. (Every Month) is selling Various Iron Scrap through auction totaling to 1000 to 1500 MT across 3 plants - Ballabgarh , Pune and Jaipur. If interested in participating in the auction Contact Aucjunction for further details.</td>
														<td><i class="fa fa-download" aria-hidden="true"></i></td>
														
													</tr>
													<tr>
													
														<td>JCB India Ltd. (Ballabgarh, Jaipur & Pune)</td>
														<td>JCB India Ltd. (Every Month) is selling Various Iron Scrap through auction totaling to 1000 to 1500 MT across 3 plants - Ballabgarh , Pune and Jaipur. If interested in participating in the auction Contact Aucjunction for further details.</td>
														<td><i class="fa fa-download" aria-hidden="true"></i></td>
														
													</tr>
													<tr>
														
														<td>JCB India Ltd. (Ballabgarh, Jaipur & Pune)</td>
														<td>JCB India Ltd. (Every Month) is selling Various Iron Scrap through auction totaling to 1000 to 1500 MT across 3 plants - Ballabgarh , Pune and Jaipur. If interested in participating in the auction Contact Aucjunction for further details.</td>
														<td><i class="fa fa-download" aria-hidden="true"></i></td>
														
													</tr>  
													<tr>
														
														<td>JCB India Ltd. (Ballabgarh, Jaipur & Pune)</td>
														<td>JCB India Ltd. (Every Month) is selling Various Iron Scrap through auction totaling to 1000 to 1500 MT across 3 plants - Ballabgarh , Pune and Jaipur. If interested in participating in the auction Contact Aucjunction for further details.</td>
														<td><i class="fa fa-download" aria-hidden="true"></i></td>
														
													</tr>  													
												</tbody>
											</table>
										</div>    		
								</div>
								<div class="tab-pane h-100 p-3 border border-primary" id="deals" role="tabpanel" aria-labelledby="hvd-tab">Upcoming Events 2</div>
								
							</div>
						</div>
				</div>
			 </div>	
		</div>
		<?php 
	include('./footer.php');
	?>