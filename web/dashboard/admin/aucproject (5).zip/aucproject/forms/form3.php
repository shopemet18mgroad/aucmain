<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="title" content=">Aucjunction | Junction For Every auction">
  <meta name="description" content="Junction For Every Auction">
  <meta name="keyword" content="Auction, metal scrapes, Ferrous, Non Ferrous and Minor Metals">
  <meta name="author" content="">
  <title>Aucjunction | Junction For Every auction</title>
  <!-- Custom fonts for this template-->
  <link href="../css/bootstrap.min.css" rel="stylesheet" type="text/css">
  <link href="../css/form-style.css" rel="stylesheet" type="text/css">
  <link href="../css/style.css" rel="stylesheet" type="text/css">
  <!-- Custom styles for this template-->
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" >
</head>
	<body class="">
	<div class="container-fluid top-header">
		<div class="row">
				<div class="col-md-12 contact-header">
					<div class="social-dash pull-right">
						<ul>
							<li><a href=""><i class="fa fa-home" aria-hidden="true"></i>&nbsp Home</a></li>
							<li><a href=""><i class="fa fa-arrow-left" aria-hidden="true"></i>&nbsp Back</a></li>
							<li><i class="fa fa-calendar" aria-hidden="true"></i>&nbsp 22-AUGUST-2020</li>
						</ul>
					</div>		
				</div>
						
		</div>	
	</div>
		
		 <div class="container">
			<div class="d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-3 bg-white border-bottom shadow-sm">
				<h5 class="my-0 mr-md-auto font-weight-normal"><a href="" title="Aucjunction Logo">
					<img class="img-fluid" alt="Aucjunction"  src="../images/aucjunction.jpg">
					</a></h5>
				
			</div>
	     </div>
		 
		
		
		<div class="container dealsbox">
			 <div class="row">
				<div class="col-md-12">
						<div class="deals-header">
							<h4><i class="icon-dashboard"></i><i class="fa fa-tachometer" aria-hidden="true"></i>&nbsp; Dashboard</h4>
						</div>
				</div>
			 </div>	
			 <div class="row">
				
				<div class="col-md-12">
					<div class="deals-tab-table">
							<ul class="nav nav-tabs border-0" id="myTab" role="tablist">
							
								
								<li class="nav-item">
									<a class="nav-link active border border-primary border-bottom-0" id="closed-tab" data-toggle="tab" href="#closed" role="tab" aria-controls="closed" aria-selected="false"><b>Form3</b></a>
								</li>
								
							</ul>

							<div class="tab-content w-100">
								<div class="tab-pane h-100 p-3 fade show active border border-primary" id="hvd" role="tabpanel" aria-labelledby="hvd-tab">
									<div class="table-holder"> 
										<div class="tab-content">
											<table class="table table-bordered table-sm">
												<thead class="thead-auc">
												
												
												</thead>
												<tbody>
												<tr><td colspan="10" style="background-color:#b2bdc3;"><strong>New Supplier Survey Form</strong></td></tr>
												
												<tr>
												<td colspan="10">
												<div class="cinpt">
												<p><strong>Namaste,</strong></p>
											
												</p>I am from<a href="“www.rawmet24.com”"> “www.rawmet24.com”</a> a subsidairy of Shopemet Networks Pvt Ltd, India’s Largest Industrial
												Raw-Material Suppliers. We are<br>currently conducting Market Survey to understand the requirements in
												procuring Raw-materials also sales of Machiniers, transformers<br> and Surplus Inventory.</p>
												<p><small>So in this regard can you please spare few minutes of your’s valuable time 3-5mins to understand and cater to your needs in a better way.</small></p>
												<p><b>note:</b> All the information provided by you will be used only for office use purposes R&D, We assure you
												confidentially at all levels, and<br>will never be shared outside Shopemet Networks Pvt Ltd.</p>
												</div>
										
												</td>
												</tr>
												
												<tr><td colspan="10">
												<div class="cinpt">
												<p>Name of the Company/Firm: 
												<input class="inpt" type="text" id="fname" name="fname" size="82"><br></p>
												<p>Corporate Office Address:
													<input class="inpt" type="text" id="fname" name="fname" size="83"><br></p>
												<p>Website/Telephone/Mobile/Email ID:
													<input class="inpt" type="text" id="fname" name="fname" size="75"><br></p>
												<p>Contact person’s Name/Designation/Number/Email:
													<input class="inpt" type="text" id="fname" name="fname" size="62"><br></p>
												<div>	
												</td></tr>
												
												
												<tr>
												<td>1.</td>
												<td>
												<div class="cinpt">
												<p><strong>Type of Business:</strong><br></p>
												
												<div class="form-check form-check-inline ">
                                                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                                <label class="form-check-label" for="exampleCheck1">Manufacture</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                                <label class="form-check-label" for="exampleCheck1">Distributer</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                                <label class="form-check-label" for="exampleCheck1">Trader</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                                <label class="form-check-label" for="exampleCheck1">Importer</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                                <label class="form-check-label" for="exampleCheck1">Secondary Metal</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                                <label class="form-check-label" for="exampleCheck1">Service provider</label>
												</div>
												</div>
				
												</td></tr>
												
												<tr>
												<td colspan="1">2.</td>
												<td>
												<div class="cinpt">
												<p><strong>Current Status:</strong><br></p>
												
												<div class="form-check form-check-inline ">
                                                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                                <label class="form-check-label" for="exampleCheck1">Proprietorship</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                                <label class="form-check-label" for="exampleCheck1">Partnership</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                                <label class="form-check-label" for="exampleCheck1">Corporation</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                                <label class="form-check-label" for="exampleCheck1">Pvt.Ltd</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                                <label class="form-check-label" for="exampleCheck1">Public sector</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                                <label class="form-check-label" for="exampleCheck1">Small business</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                                <label class="form-check-label" for="exampleCheck1">India licensed</label>
												</div>
												</div>
												
												
												</td></tr>
												
												<tr>
												<td colspan="1">3.</td>
												<td>
												<div class="cinpt">
												<p>When was your organisation established:
												<input class="inpt" type="text" id="fname" name="fname" size="80"></p>
												<p>How many location do you have across India:
												<input class="inpt" type="text" id="fname" name="fname" size="80"></p>		
												</td>
												</tr>
												
												
												</td></tr>
												
												<tr>
												<td colspan="1">4.</td>
												<td>
												<div class="cinpt">
												<p>Please tell me how do you typically procure Raw-material?<br></p>
											
												Websites(Online) <div class="form-check form-check-inline ">
                                                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                                <label class="form-check-label" for="exampleCheck1"></label>
												</div>
												
												Traditional(offline) <div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                                <label class="form-check-label" for="exampleCheck1"></label>
												</div>
												</div>
												
												</td></tr>
												<tr>
												<td>5.</td>
												<td>
												<div class="cinpt">
												<p>Please tell me which of the following Products/Materials do you typically procure/sell
												day to day operations?<br></p>
												
												<div class="form-check form-check-inline ">
                                                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                                <label class="form-check-label" for="exampleCheck1">Ferrous Metals</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                                <label class="form-check-label" for="exampleCheck1">Non Ferrous Metals</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                                <label class="form-check-label" for="exampleCheck1">Minor Metals</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                                <label class="form-check-label" for="exampleCheck1">Paper Materials</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                                <label class="form-check-label" for="exampleCheck1">Plastic Materials</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                                <label class="form-check-label" for="exampleCheck1">Construction Materials</label>
												</div>
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                                <label class="form-check-label" for="exampleCheck1">Others,pls specify:</label>
												</div>
												</div>
												
												</td></tr>
												<tr>
												<td>6.</td>
												<td>
												<div class="cinpt">
												<p>If applicable, list the name of your parent company and subsidiary:<br></p>
												<p>Parent:
												<input class="inpt" type="text" id="fname" name="fname" size="50"></p>
												<p>Subsidiary:
												<input class="inpt" type="text" id="fname" name="fname" size="50"></p>
												</div>
												</td>
												</tr>
												
												<tr>
												<td>7.</td>
												<td>
											    <div class="cinpt">
												<p>Are you importing any product category’s from outside India, if yes what product? Country imported?<br>
												
												<input class="inpt" type="text" id="fname" name="fname" size="75">
												<input class="inpt" type="text" id="fname" name="fname" size="75"></p>
											     <div>
												
												</td></tr>
												
												<tr>
												<td>8.</td>
												<td>
												<div class="cinpt">
												<p>Primary industry or line of business at this location? What is the principal product or service at this
												location? Please specify all the product category’s Materials do you typically procure/sell depending
												on day to day operations?<br>
												
												<input class="inpt" type="text" id="fname" name="fname" size="75">
												<input class="inpt" type="text" id="fname" name="fname" size="75"></p>
												</div>
												
												</td></tr>
												
												<tr>
												<td>9.</td>
												<td>	
												<div class="cinpt">
												<p>When I talk about Raw-material procurement Websites in India, What all Websites you are aware of to
												(Sell or Buy) Raw-materials??<br>
												
												<input class="inpt" type="text" id="fname" name="fname" size="75">
												<input class="inpt" type="text" id="fname" name="fname" size="75"></p>
												</div>
												</td></tr>
												
												<tr>
												<td>10.</td>
												
												<td>
												<div class="cinpt">
												<p>taken to clear the stock/how fast is stock cleared, once you get a lot in
												your gowrdon?<br>
												
												<input class="inpt" type="text" id="fname" name="fname" size="75">
												<input class="inpt" type="text" id="fname" name="fname" size="75"></p>
												</div>
												
												</td></tr>
												 
												 <tr>
												<td>11.</td>
												<td>
												<div class="cinpt">
												<p>Is transportaion free of cost or chargeable? is it with Karnataka, only with south India or Pan India
												transportation<br>
												
												<input class="inpt" type="text" id="fname" name="fname" size="75">
												<input class="inpt" type="text" id="fname" name="fname" size="75"></p>
												
												</div>
												</td></tr>
												<tr>
												<td>12.</td>
												<td>
												<div class="cinpt">
												<p>How fast can you deliver once the order is place at “TAT”? with 24h, 48h, 72h, or one week<br>
												
												<input class="inpt" type="text" id="fname" name="fname" size="75">
												<input class="inpt" type="text" id="fname" name="fname" size="75"></p>
												</div>
												
												</td></tr>
											
												<tr>
												<td>13.</td>
												<td>
												<div class="cinpt">
												<p>Do you have any kind of “CAP”while placing every order, like minimum order should by “5” Tons,
												”1000” KG, so on? if yes please specify<br>
												
												<input class="inpt" type="text" id="fname" name="fname" size="75">
												<input class="inpt" type="text" id="fname" name="fname" size="75"></p>
												</div>
												
												</td></tr>
											
												<tr>
												<td>14.</td>
												<td>
												<div class="cinpt">
												<p>If required, can you provide documentation for material/testing conformance to applicable specifications
												(e.g., material<br> certifications, quality certificates of conformance/complice MSDL)?<br></p>
												
												
												Yes
												<div class="form-check form-check-inline ">
                                                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                                <label class="form-check-label" for="exampleCheck1"></label>
												</div>
												No
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                                <label class="form-check-label" for="exampleCheck1"></label>
												</div>
												</div>

												</td></tr>
											
												<tr>
												<td>15.</td>
												<td>
												<div class="cinpt">
												<p>Is there a system in place to review, promtly resolve, take corrective/preventive action for customer
												complaints?<br></p>
												
												Yes
												<div class="form-check form-check-inline ">
                                                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                                <label class="form-check-label" for="exampleCheck1"></label>
												</div>
												No
												<div class="form-check form-check-inline">
                                                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                                <label class="form-check-label" for="exampleCheck1"></label>
												</div>
												</div>

												</td></tr>
												
												<tr>
												<td width="5%">16.</td>
												<td>
												<div class="cinpt">
												<p>Payment Terms, Credit period for industries against PDC:
												
												<input class="inpt" type="text" id="fname" name="fname" size="75">
												<p class="para">Annual sales(turnover):
												<input class="inpt" type="text" id="fname" name="fname" size="75"></p>
												</div>
												
												</td></tr>
												<tr>
												<td colspan="10">
												<div class="cinpt">
												<p> For further documentation/ernpanelment one of my Manager will get in touch with you, very, soon once again thank you so much for<br> your time</p>
												</div>
												</td>
												</tr>
											</tbody>
											</table>
													<a href="#"><button type="button" class="btn btn-primary">Submit</button></a>
												
												
											
								
							</div>
						</div>
				</div>
			</div>	
		</div>
		</div>
		</div>
		</div>
		
		<section id="footer">
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-1">
					<ul class="list-unstyled list-inline social text-center">
						<li class="list-inline-item"><a href=""><i class="fa fa-facebook"></i></a></li>
						<li class="list-inline-item"><a href=""><i class="fa fa-twitter"></i></a></li>
						<li class="list-inline-item"><a href=""><i class="fa fa-instagram"></i></a></li>
						<li class="list-inline-item"><a href=""><i class="fa fa-google-plus"></i></a></li>
						<li class="list-inline-item"><a href="" target="_blank"><i class="fa fa-envelope"></i></a></li>
					</ul>
				</div>
				<hr>
			</div>	
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 mt-1 mt-sm-1 text-center text-white">
					<p>Shopemet Networks Private Limited CIN NO :- 2097898098089</p>
					<p class="h6">Aucjunction © All right Reversed.</p>
				</div>
				<hr>
			</div>	
		</div>
	</section>
		
		
		

	
  <!-- Bootstrap core JavaScript-->	
  <script src="js/jquery-3.2.2.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.bundle.min.js"></script>
  <script src="js/jquery.autoscroll.js" type="text/javascript" charset="utf-8"></script>
  <!-- Core plugin JavaScript-->

</body>

</html>
