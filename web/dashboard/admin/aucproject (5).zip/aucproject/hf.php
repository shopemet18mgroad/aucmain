<?php 
	include('./header.php');
?>
		
		<!--body design-->
		
		
		
		    
<div class= "content">
	<div class="middleboxtnc">
		<div class="middle">
			<h2 style="text-align:center"><b>Aucjunction</b><h2>
			<h6 style="text-align:center">Junction for every auction</h6> 
			<p>Corp Office: Bangalore
				#179, 2nd Floor, Mysore Road Cross, Bangalore - 560 002
				Offcial Email:info@shopemet.in
				Phone:+91 9980596460
				Website:www.rawmet24.com
				www.aucjunction.com</p>
		</div>
		<div class="blnkspc">


			<table width="100%" border="0" cellspacing="0" cellpadding="0">
				<div class="bar">
					<p><strong>TERMS AND CONDITIONS</strong></p>
				</div>


				<div class="space">
<p class="termstxt2">1. WELCOME TO AUCJUNCTION !</p>
		<P class= "para">This unique service of auction on the net is offered to you, subject to the following General Terms & Conditions of Service ("GTC"), which may be updated by us from time to time without notice to you. You can review the most current version of the GTC at any time at: www.mstcecommerce.com. In addition, when using particular MSTC services, you and MSTC shall be subject to any posted Guidelines or Rules applicable to such services which may be posted from time to time. All such Guidelines or Rules are hereby incorporated by reference into the GTC. MSTC also may offer other services from time to time, such as that are governed by different General Terms & Conditions of Services.</P>

		<p class="termstxt2">2.AGREEMENT :-</p>
			<pre class="para">
7.1
MSTC shall conduct auction sale directly and in no case the appointment of any dealer/trader/auctioneer for the purpose
 will be considered.
7.2
MSTC will offer guidance in regard to making of lots for the purpose of Auction and will act on the basis of the list
 of disposable materials received from the Principal.
7.3
MSTC may arrange publicity for disposal through E-auctions by way of occasional advertisements in leading dailies /
 Newspapers / Websites and other Internet Tools. In addition the system shall notify automatically to all the buyers
 who are registered with the auction website i.e www.mstcecommerce.com regarding all the forthcoming E-auctions specifying 
 therein all relevant details about the materials / Lots / date & time of opening & closing of auctions etc. 
 In case the Principal desires publicity through a particular publication or media, the same would be arranged on receipt
 of written request and the additional cost has to be borne by the Principal.
7.4
MSTC shall arrange disposal of the materials primarily through auction via the website www.mstcecommerce.com.
7.5
On the close of any auction Principal will receive a system generated Email indicating the status of the Auction which
 will inter alia include Sold Lots, Subject To Approval (STA) lots and also lots not sold with highest bid received for
 Principal’s record. The Principal shall have the option to visit the website in order to obtain a full report of any 
 particular auction, which will normally depict the replica of the Bid Sheet of a particular auction.
7.6
Reserve Price must be fixed and entered by the Principal in the website, which will be only accessible by the 
Principal and none else, for the disposable materials. In case the Reserve price is not entered by the principal
 prior to commencement of the Auction, the lots for which the reserve price have not been entered, shall stand 
 automatically withdrawn by the system.
7.7
If, in respect of any item(s) covered under the Selling Agency Agreement, it is desired by the Principal to have a 
arket survey, the costs for the same will have to be borne by the Principal. The market survey could be done by MSTC
 themselves or by engaging consultants.
7.8
MSTC shall enter into sale contracts with the successful bidders/ buyers/customers by issuing Sale Orders/Acceptance
 Letters on behalf of the Principal through the system for the sold lots.
7.9
MSTC shall accept sale price/bid money for onward submission to the Principal, off line. The successful buyers will
 have the option to remit their money to any of the offices of MSTC. The principals will be able to access data 
 of payments etc., at the website.
7.10
Wherever the Principal is not registered under the appropriate Sales Tax Act, MSTC shall collect Sales Tax as 
applicable and other declaration forms and submit the same to the Appropriate Authority. For such service, an 
additional Service Charge of 0.5% will be payable by the Principal to MSTC.
</pre>

<!--<p class="termstxt2">2.Personal Details :-</p>
<p class="para">

1.0 
THIS AGREEMENT made this&nbsp;<input type= "text" name="username" id = "username" size="25">day of&nbsp;<input type= "text" name="username" id = "username" size="25"> 
<br>BETWEEN M/s. &nbsp;<input type= "text" name="username" id = "username" size="25"> incorporated 
under the Companies Act, 1956 and having its registered office at&nbsp;<input type= "text" name="username" id = "username" size="25">, 
hereinafter called "the Principal"(which expression shall unless excluded by or repugnant to the context
be deemed to include its successors and assigns) on the ONE PART; AND MSTC Limited (A Govt. of India Enterprise) 
incorporated under the Companies Act, 1956 and having its registered office at 225-C, Acharya Jagadish Chandra Bose Road, Calcutta-700 020, 
hereinafter called "MSTC" (which expression shall unless excluded by or repugnant to the context be deemed 
to include its successors and assigns) on the Other part ;
</p>
-->
			
				</div>
			</table>


			<div class= "center">
				<a href='agreementforseller.html'><button  type="button" class="btn btn-primary">Seller Register</button></a>
				<a href='agreementforbuyer.html'><button type="button" class="btn btn-primary">Buyer Register</button></a>

			</div>

		</div>
  
	</div>   
    
  </div>  
    
		
		
		
		
		
		
		
		<!--body design-->
		<?php 
	include('./footer.php');
?>