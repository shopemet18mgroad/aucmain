<?php 
	include('./header.php');
?>
		<div class="container">
		  <div class="row">
			<div class="col-md-12">
			 <div class="aboutus-section">
        <div class="container">
			  <div class="row">
				<div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="aboutus">
                        <h2 class="aboutus-title">INTRODUCTION</h2>
                        <p class="aboutus-text">Shopemet Networks Pvt Ltd was built up in 2018 to offer an extensive assistance to makers of Machnical Equipments, Machineries, Electornic Equipments and building items in Indian markets just as outside India.
</br></br>
			From our offices based at Bangalore, we arrange deliveries of a wide range of quality raw materials which we source from leading manufacturers worldwide. Our expertise in all aspects of procuring and moving goods has resulted in us becoming a leading supplier to manufacturing industries in our market territories.
</br></br>
			Shopemet Networks supplies just about any raw material which might be needed, and we control the entire process of moving goods from factory to destination to ensure minimum delays of your consignments. We are also able to consolidate mixed container loads of smaller items at our warehouse, again ensuring safe and efficient carriage to final destination.</p>
 
                    </div>
                </div>
			  </div>
            <div class="row">
                <div class="col-md-6 col-sm-6 col-xs-12">
                    <div class="aboutus">
                        <h2 class="aboutus-title">About Us</h2>
                        <p class="aboutus-text">Our Product is the Most reputed private online auction portal operating in the specialized space of buying and selling surplus inventory. We will provide a comprehensive online marketplace for companies to buy and sell residual and superfluous inventory - from raw material, machinery and industrial by-products to non-performing and stressed assets. Our service offerings include tender management, Purchase and Sale of Industrial Scrap as well as purchase and sale of repossessed vehicles and machineries</p>
						<div class="about-us-img">
							<img src="images/about-img.jpg"></img>
						</div>
                    </div>
                </div>

                <div class="col-md-6 col-sm-6 col-xs-12">
                    <div class="feature">
                        <div class="feature-box">
                            <div class="clearfix">
                                <div class="iconset">
                                    <span class="fa fa-hand-o-right fa-4x"></span>
                                </div>
                                <div class="feature-content">
                                    <h4>Our Mission</h4>
                                    <p>Provide the Best Supply & Disposal Solutions for all Industries; To build the largest network of Industrial Raw materials buyers at all levels; to build a platform where we can assimilate & process the world's Ras materials inventory and sync it with our customer and associates.</p>
									
									
                                </div>
                            </div>
                        </div>
                        <div class="feature-box">
                            <div class="clearfix">
                                <div class="iconset">
                                    <span class="fa fa-hand-o-right fa-4x"></span>
                                </div>
                                <div class="feature-content">
                                    <h4>Our Vision</h4>
                                    <p>Our vision is to participate consistently in extending generation limits and expanding our Raw material supplying, Auctioning and Multi business capacities with specific goals to meet the developing world wide demand and therefore hold our position at the front of Industrial and Service Business.</br>

To Be industry leader in delivering quality products and quality services and innovative solutions that address our partner suppliers and customers most challenging Raw material needs and Disposal needs for the future. Our efforts is our belief we must operate as a company committed to COC and Principle Values.</br>

Our vision is about more than Metals it is about reinforcing the economic and social benefits associated with strong Indian and Global Manufacturing Capabilities of which metals is a foundational industry.</br>

We are committed to finding ways to innovate, grow, and overcome obstacles in order to create value and benefit the long-term interests of all Shopemet Networks Pvt Ltd stakeholders, employees, suppliers, customers and the communities where we do business.</p>
                                </div>
                            </div>
                        </div>
                        <div class="feature-box">
                            <div class="clearfix">
                                <div class="iconset">
                                    <span class="fa fa-hand-o-right fa-4x"></span>
                                </div>
                                <div class="feature-content">
                                    <h4>Our Objective</h4>
                                    <p>We aim to ended up as an biggest exchanging company of India and a major exchanging company of Asia and moving forward its position assist by accomplishing economical and reasonable development rate through greatness in all its exercises producing ideal benefits through add up to fulfillment of shareholders, clients, providers, workers and society.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
			   
			</div>
			
			
		  </div>
		</div>
		
		<?php 
	include('./footer.php');
?>