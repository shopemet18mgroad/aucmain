<?php 
	include('./header.php');
?>
		<div class="container">
		  <div class="row">
			<div class="col-md-12">
			 <div class="aboutus-section">
        <div class="container">
			  <div class="row">
				<div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="aboutus">
                        <h2 class="aboutus-title">E-AUCTIONS DOCUMENTS</h2>
                        <p class="aboutus-text"><span class="textsize">Along with the payment as above you are also advised to furnish the following documents mandatorily to make your account operative:</span>
</br></br>
<span class="fontbld">1.</span> Income Tax PAN Card (Original &amp; Photocopy - the Original will be returned after verification).
In case of a registered Company or Firm, the Firm&#39;s PAN card and in case of a proprietorship
firm, proprietor’s personal PAN card is required.
</br></br>
<span class="fontbld">2.</span> Photocopy of Latest Income Tax Return.
</br></br>
<span class="fontbld">3.</span> Photocopies of Sales Tax Registration Certificates (State &amp; Central).
</br></br>
<span class="fontbld">4.</span> Signature of the Proprietor / Partner verified by Bank (If Proprietorship / Partnership Firm) on
Bank&#39;s Letter-head. If such verification is done on Customer&#39;s Letter-head, then the full Address
of the Branch of the Bank must be mentioned.
</br></br>
<span class="fontbld">5.</span> Two Passport size Color Photographs of the Proprietor / Partner / Director ( for issue of
Photo ID card by MSTC) - The Proprietor / Partner / Director ( or a person authorized by the
Director in case of Public / Private limited Company) of the Customer&#39;s Firm will be required to
put his specimen signature on the ID Card. In case of Proprietorship / Partnership Firm, the
Proprietor / Partner will be required to sign the impanelment agreement executive visiting your
office. In case of Public / Private Limited Company, this may be done by requesting Shopemet
Networks Pvt Ltd to send the impanelment agreement where it can be signed and return to
Shopemet Networks Pvt Ltd. It will be the Customer&#39;s responsibility to ensure that he obtains the
duly authorized Copy of Impanelment agreement from Shopement Networks Pvt Ltd.
</br></br>
<span class="fontbld">6.</span> Notarized Photocopies of Valid Registration Certificates from Central and State Pollution
Control Boards for Hazardous Waste items (If applicable) - It may be noted that on receipt of the
said Certificates, Shopement Networks Pvt Ltd will record the Validity Period of the Customer&#39;s
CPCB certificate in the buyer registration Form on the website and only thereafter the registered
customers will be allowed access into the Live-eAuction floor for bidding for Hazardous Waste
items subject to their CPCB certificate being valid on the starting date of e-Auction. However
this will be governed by the special Terms &amp; Conditions of the particular e-Auction and it will
always be the Customer&#39;s responsibility to ensure that both his SPCB &amp; CPCB certificates are
kept valid or duly revalidated within the prescribed time for the purpose of participating in the e-
Auction in accordance with the stipulated special Terms &amp; Conditions if the particular eAuction.
</br></br>
<span class="fontbld">7.</span> Copy of email confirmation Letter received from Shopement Networks Pvt ltd after successful
completion of on-line registration and containing buyer registration details of the Customer -
This should be duly counter-signed by the Customer and returend to Shopement Networks Pvt
Ltd along with his offline documents for verification.
</br></br>
<span class="fontbld">8.</span> Copy of partnership deed to be submitted for partnership firms.
Originals of the above documents may please be produced for verification at the time of
Shopmet’s Executive visits your Office/Factory.</p>
<p><span class="textsize">Registration fee:</span></p>
</br>
<p class="aboutus-text">In order to participate in our on-line E-auctions, you are requested to pay a one-time non-
refundable Subscription fee of Rs, 7850/- ( Rs 7850 + service tax @ 18 % of 1413 ) in form of
DD/Online Payment using our Payment Gateway in favour of Shopemet Networks Pvt Ltd
payable at respective Region / Branch at any office of Shopemet Networks Pvt Ltd within 10
days otherwise your details will be deleted from our database.</p>
                    </div>
                </div>
			  </div>
            
        </div>
    </div>
			   
			</div>
			
			
		  </div>
		</div>
		
		<?php 
	include('./footer.php');
?>